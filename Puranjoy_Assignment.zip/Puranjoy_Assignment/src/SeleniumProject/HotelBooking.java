package SeleniumProject;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class HotelBooking {
	
	public static void main(String[] args) {
		
		System.setProperty("webdriver.chrome.driver","C:\\Puranjoy\\Selenium\\NewChromeDriver\\chromedriver.exe");
		WebDriver driver= new ChromeDriver();
		driver.get("C://Puranjoy//Selenium//original_1588252119_Testing_Casestudy_HotelBooking//Casestudy_HotelBooking/login.html");
		
		//verify header present
		
			if(driver.findElement(By.xpath("//h1[text()=' Hotel Booking Application ']"))!= null){

			System.out.println("Header is present");

			}else{

			System.out.println("Header is not present");
			}
			
			//Click Login button without username
			
			WebElement login = driver.findElement(By.xpath("//*[@value='Login']"));
			login.click();	
			if(driver.findElement(By.xpath("//div[text()=' * Please enter userName.']"))!= null){

				System.out.println("Please enter userName");
				}
			
			//Click Login button without password			
			 		
	        WebElement email = driver.findElement(By.xpath("//*[@name='userName']"));	
	        email.sendKeys("abcd@gmail.com");
	        login.click();
	        if(driver.findElement(By.xpath("//div[text()=' * Please enter password.']"))!= null){

				System.out.println("Please enter Password");

				}
	        email.clear();
	        
	        //Successful login
	        
	        WebElement password = driver.findElement(By.xpath("//*[@name='userPwd']"));
	        email.sendKeys("admin");
	        password.sendKeys("admin");
	        login.click();
	        
	        if(driver.findElement(By.xpath("//h2[text()='Hotel Booking Form']"))!= null){

				System.out.println("Login Successful");

				}else{

				System.out.println("Login Failed");

				}
	        
	        //Without entering any text click Confirm Booking button
	        
	        WebElement ConfirmBooking = driver.findElement(By.xpath("//*[@value='Confirm Booking']"));
	        ConfirmBooking.click();
	        
	        Alert alert = driver.switchTo().alert();		

	        String alertMessage= driver.switchTo().alert().getText();		
	
	        System.out.println(alertMessage);
	        alert.accept();
	        
	        //Enter firstname keep lastname blank
	        
	        WebElement firstname = driver.findElement(By.xpath("//*[@id='txtFirstName']"));
	        firstname.sendKeys("Puranjoy");
	        ConfirmBooking.click();
	        String alertMessage1= driver.switchTo().alert().getText();		
	    	
	        System.out.println(alertMessage1);
	        alert.accept();
	        
	        
	        // Enter Invalid email format
	        
	        WebElement SecondName = driver.findElement(By.xpath("//*[@id='txtLastName']"));
	        WebElement CustEmail =  driver.findElement(By.xpath("//*[@id='txtEmail']"));
	        firstname.sendKeys("Puranjoy");
	        SecondName.sendKeys("Banerjee");
	        CustEmail.sendKeys("Puranjoy");
	        ConfirmBooking.click();
	        String alertMessage2= driver.switchTo().alert().getText();		
	    	
	        System.out.println(alertMessage2);
	        alert.accept();
	        
	        //keep mobile number field blank
	        
	        WebElement Phone = driver.findElement(By.xpath("//*[@id='txtPhone']"));
	        CustEmail.sendKeys("@gmail.com");
	        ConfirmBooking.click();
	        String alertMessage3= driver.switchTo().alert().getText();		
	    	
	        System.out.println(alertMessage3);
	        alert.accept();
	        
	        //Display alert for invalid mobile number
	        
	        Phone.sendKeys("123456");
	        ConfirmBooking.click();
	        String alertMessage4= driver.switchTo().alert().getText();		
	        System.out.println(alertMessage4);
	        alert.accept();
	        Phone.clear();
	        
	        //Provide address
	        
	        WebElement Address = driver.findElement(By.xpath("//*[@rows='5']"));
	        Phone.sendKeys("7895620258");
	        Address.sendKeys("TCS Kolkata");
	        
	        //Click Confirm without select city
	        
	        WebElement city = driver.findElement(By.xpath("//*[@name='city']"));
	        ConfirmBooking.click();
	        String alertMessage5= driver.switchTo().alert().getText();		
	        System.out.println(alertMessage5);
	        alert.accept();
	       
	        //Click Confirm without select State
	        
	        WebElement state = driver.findElement(By.xpath("//*[@name='state']"));
	        city.selectByIndex(2);
	        ConfirmBooking.click();
	        String alertMessage6= driver.switchTo().alert().getText();		
	        System.out.println(alertMessage6);
	        alert.accept();
	        
	      //Click Confirm without select card holder name
	        
	        WebElement CardhldName = driver.findElement(By.xpath("//*[@id='txtCardholderName']"));
	        city.selectByIndex(2);
	        state.selectByIndex(2);
	        ConfirmBooking.click();
	        String alertMessage7= driver.switchTo().alert().getText();		
	        System.out.println(alertMessage7);
	        alert.accept();
	        
	        //Without Debit card number
	        
	        WebElement CardhldNum = driver.findElement(By.xpath("//*[@id='txtDebit']"));
	        CardhldName.sendKeys("Puranjoy");
	        ConfirmBooking.click();
	        String alertMessage8= driver.switchTo().alert().getText();		
	        System.out.println(alertMessage8);
	        alert.accept();
	        
	        //Without CVV
	        
	        WebElement CVV = driver.findElement(By.xpath("//*[@id='txtCvv']"));
	        CardhldNum.sendKeys("123456");
	        ConfirmBooking.click();
	        String alertMessage9= driver.switchTo().alert().getText();		
	        System.out.println(alertMessage9);
	        alert.accept();
	        
	        //Without Expiration month
	        
	        WebElement ExpMnth = driver.findElement(By.xpath("//*[@id='txtMonth']"));
	        CVV.sendKeys("6699");
	        ConfirmBooking.click();
	        String alertMessage10= driver.switchTo().alert().getText();		
	        System.out.println(alertMessage10);
	        alert.accept();
	        
	      //Without Expiration Year
	        
	        WebElement ExpYear = driver.findElement(By.xpath("//*[@id='txtYear']"));
	        ExpMnth.sendKeys("03");
	        ConfirmBooking.click();
	        String alertMessage11= driver.switchTo().alert().getText();		
	        System.out.println(alertMessage11);
	        alert.accept();
	        
	        //Success Page
	        
	        ExpYear.sendKeys("2025");
	        ConfirmBooking.click();
	        
	        if(driver.findElement(By.xpath("//h1[text()='Booking Completed!']"))!= null){

				System.out.println("Booking Completed");

				}else{

				System.out.println("Booking not completed");

				}
		System.out.println("SUCCESS");
	}
	

}
